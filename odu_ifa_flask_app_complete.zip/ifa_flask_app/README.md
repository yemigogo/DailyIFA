# Odu Ifá Flask App

## Overview
Complete Flask application displaying all 256 Odu Ifá cards with black backgrounds and wooden carving textures.

## Setup
1. Install dependencies: `pip install -r requirements.txt`
2. Run the app: `python app.py`
3. Open browser to: `http://localhost:5000`

## Features
- 256 authentic Odu cards from Excel matrix data
- Black backgrounds with wooden carving textures
- Responsive web display
- Cards sorted numerically (1-256)

## Structure
- `app.py` - Flask application
- `templates/index.html` - HTML template
- `static/` - 256 Odu card images
- `requirements.txt` - Python dependencies

Generated: 2025-07-11 19:58:44
