# Filtered 256 Odu Ifá Cards

## Collection Summary
This archive contains 256 Odu cards with valid integer numbers 1-256.

## Filter Criteria
- Filename format: odu_card_{integer}.png
- Number range: 1 to 256
- Only cards with valid integer numbers included

## Card Specifications
- Size: 600x800 pixels
- Background: Black
- Text: White
- Wood carving texture with sacred symbols
- Traditional Odu names and I/II patterns

## Files Included
256 card images from odu_card_1.png to odu_card_256.png

Generated: 2025-07-11 19:44:06
